/**
 * Menu Item
 */

const menuItems = [
  {
    id: 1,
    name: "Margherita",
    price: 5.99,
  },
  {
    id: 2,
    name: "Pepperoni",
    price: 6.99,
  },
  {
    id: 3,
    name: "Neapolitan",
    price: 7.99,
  },
  {
    id: 4,
    name: "New York Style",
    price: 10.99,
  },
  {
    id: 5,
    name: "Sicilian",
    price: 12.99,
  },
];

module.exports = menuItems;
